package com.deadman.checkin

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()

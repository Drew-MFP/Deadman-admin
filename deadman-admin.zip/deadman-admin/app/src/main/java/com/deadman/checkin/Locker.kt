package com.deadman.checkin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

object Locker {
    /** Returns null on success, or an error message. */
    fun applyPin(ctx: Context, pin: String): String? {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(ctx, AdminReceiver::class.java)
        val token = Store(ctx).token
        if (token != null) {
            try {
                if (dpm.resetPasswordWithToken(admin, pin, token, 0)) return null
            } catch (e: Exception) { /* fall through to older method */ }
        }
        return try {
            @Suppress("DEPRECATION")
            if (dpm.resetPassword(pin, 0)) null else "resetPassword returned false"
        } catch (e: Exception) {
            e.message ?: e.toString()
        }
    }

    fun lock(ctx: Context) {
        ctx.getSystemService(DevicePolicyManager::class.java).lockNow()
    }
}

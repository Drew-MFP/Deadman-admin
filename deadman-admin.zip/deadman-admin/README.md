# Deadman Check-in

Locks the tablet with a different PIN if you don't enter your check-in code within the time limit.
Android 8+ (built for Android 10). Needs Device Owner.

## Build on GitHub
1. Create a repo, upload all these files, push to `main`.
2. Actions tab -> "Build APK" -> download the `deadman-checkin-apk` artifact (app-debug.apk).

## Install
1. Remove ALL accounts (Google etc.) from the tablet temporarily.
2. `adb install app-debug.apk`
3. `adb shell dpm set-device-owner com.deadman.checkin/.AdminReceiver`
4. Open the app, fill in Setup, tap "Save & start timer".
5. If you have a lock set, tap "Activate reset token" and confirm your current PIN.
   Status must show Token active: true.
6. Test with a limit of ~20 minutes first (the check runs every ~15 min).
   Note: the new PIN is stored in plain app storage so the app can apply it.

## Uninstall
Open the app, enter either code in Remove, tap Remove, then uninstall normally.
